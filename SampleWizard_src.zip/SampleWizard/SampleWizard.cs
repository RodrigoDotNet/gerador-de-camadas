#region Copyright �2005, Cristi Potlog - All Rights Reserved
/* ------------------------------------------------------------------- *
*                            Cristi Potlog                             *
*                  Copyright �2005 - All Rights reserved               *
*                                                                      *
* THIS SOURCE CODE IS PROVIDED "AS IS" WITH NO WARRANTIES OF ANY KIND, *
* EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE        *
* WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR   *
* PURPOSE, NONINFRINGEMENT, OR ARISING FROM A COURSE OF DEALING,       *
* USAGE OR TRADE PRACTICE.                                             *
*                                                                      *
* THIS COPYRIGHT NOTICE MAY NOT BE REMOVED FROM THIS FILE.             *
* ------------------------------------------------------------------- */
#endregion Copyright �2005, Cristi Potlog - All Rights Reserved

#region References
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CristiPotlog.Controls;
#endregion

namespace CristiPotlog.SampleWizard
{
	/// <summary>
	/// Summary description for SampleWizard.
	/// </summary>
	public class SampleWizard : System.Windows.Forms.Form
	{
		#region Designer generated code
		private System.Windows.Forms.CheckBox checkIAgree;
		private System.Windows.Forms.TextBox textLicense;
		private CristiPotlog.Controls.WizardPage pageLicense;
		private CristiPotlog.Controls.WizardPage pageOptions;
		private CristiPotlog.Controls.WizardPage pageFinish;
		private CristiPotlog.Controls.WizardPage pageWelcome;
		private CristiPotlog.Controls.WizardPage pageProgress;
		private CristiPotlog.Controls.Wizard wizardSample;
		private System.Windows.Forms.ProgressBar progressLongTask;
		private System.Windows.Forms.Label labelProgress;
		private System.Windows.Forms.Timer timerTask;
		private System.Windows.Forms.GroupBox groupOptions;
        private System.Windows.Forms.RadioButton optionSkip;
        private System.Windows.Forms.RadioButton optionCheck;
        private CristiPotlog.Controls.WizardPage pageCheck;
        private System.Windows.Forms.Label labelPlaceholder;
		private System.ComponentModel.IContainer components;
		#endregion

		#region Constructor & Dispose
		/// <summary>
		/// Creates a new instance of the <see cref="SampleWizard"/> class.
		/// </summary>
		public SampleWizard()
		{
			// required for designer support
			this.InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (this.components != null) 
				{
					this.components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		#endregion

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(SampleWizard));
            this.pageLicense = new CristiPotlog.Controls.WizardPage();
            this.checkIAgree = new System.Windows.Forms.CheckBox();
            this.textLicense = new System.Windows.Forms.TextBox();
            this.pageOptions = new CristiPotlog.Controls.WizardPage();
            this.groupOptions = new System.Windows.Forms.GroupBox();
            this.optionSkip = new System.Windows.Forms.RadioButton();
            this.optionCheck = new System.Windows.Forms.RadioButton();
            this.pageFinish = new CristiPotlog.Controls.WizardPage();
            this.wizardSample = new CristiPotlog.Controls.Wizard();
            this.pageWelcome = new CristiPotlog.Controls.WizardPage();
            this.pageProgress = new CristiPotlog.Controls.WizardPage();
            this.labelProgress = new System.Windows.Forms.Label();
            this.progressLongTask = new System.Windows.Forms.ProgressBar();
            this.pageCheck = new CristiPotlog.Controls.WizardPage();
            this.timerTask = new System.Windows.Forms.Timer(this.components);
            this.labelPlaceholder = new System.Windows.Forms.Label();
            this.pageLicense.SuspendLayout();
            this.pageOptions.SuspendLayout();
            this.groupOptions.SuspendLayout();
            this.wizardSample.SuspendLayout();
            this.pageProgress.SuspendLayout();
            this.pageCheck.SuspendLayout();
            this.SuspendLayout();
            // 
            // pageLicense
            // 
            this.pageLicense.Controls.Add(this.checkIAgree);
            this.pageLicense.Controls.Add(this.textLicense);
            this.pageLicense.Description = "Please read the following license agreement and confirm that you agree with all t" +
                "erms and conditions.";
            this.pageLicense.Location = new System.Drawing.Point(0, 0);
            this.pageLicense.Name = "pageLicense";
            this.pageLicense.Size = new System.Drawing.Size(466, 296);
            this.pageLicense.TabIndex = 10;
            this.pageLicense.Title = "License Agreement";
            // 
            // checkIAgree
            // 
            this.checkIAgree.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.checkIAgree.Location = new System.Drawing.Point(12, 272);
            this.checkIAgree.Name = "checkIAgree";
            this.checkIAgree.Size = new System.Drawing.Size(288, 16);
            this.checkIAgree.TabIndex = 0;
            this.checkIAgree.Text = "I agree with this license\'s terms and conditions.";
            this.checkIAgree.CheckedChanged += new System.EventHandler(this.checkIAgree_CheckedChanged);
            // 
            // textLicense
            // 
            this.textLicense.BackColor = System.Drawing.SystemColors.Window;
            this.textLicense.Location = new System.Drawing.Point(12, 76);
            this.textLicense.Multiline = true;
            this.textLicense.Name = "textLicense";
            this.textLicense.ReadOnly = true;
            this.textLicense.Size = new System.Drawing.Size(440, 188);
            this.textLicense.TabIndex = 1;
            this.textLicense.Text = "Some long and boring license text...";
            // 
            // pageOptions
            // 
            this.pageOptions.Controls.Add(this.groupOptions);
            this.pageOptions.Description = "Please select an option from the available list.";
            this.pageOptions.Location = new System.Drawing.Point(0, 0);
            this.pageOptions.Name = "pageOptions";
            this.pageOptions.Size = new System.Drawing.Size(466, 296);
            this.pageOptions.TabIndex = 11;
            this.pageOptions.Title = "Task Options";
            // 
            // groupOptions
            // 
            this.groupOptions.Controls.Add(this.optionSkip);
            this.groupOptions.Controls.Add(this.optionCheck);
            this.groupOptions.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupOptions.Location = new System.Drawing.Point(16, 84);
            this.groupOptions.Name = "groupOptions";
            this.groupOptions.Size = new System.Drawing.Size(436, 112);
            this.groupOptions.TabIndex = 0;
            this.groupOptions.TabStop = false;
            this.groupOptions.Text = "Available Options";
            // 
            // optionSkip
            // 
            this.optionSkip.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.optionSkip.Location = new System.Drawing.Point(20, 36);
            this.optionSkip.Name = "optionSkip";
            this.optionSkip.Size = new System.Drawing.Size(260, 20);
            this.optionSkip.TabIndex = 0;
            this.optionSkip.Text = "Skip any checks and proceed.";
            // 
            // optionCheck
            // 
            this.optionCheck.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.optionCheck.Location = new System.Drawing.Point(20, 72);
            this.optionCheck.Name = "optionCheck";
            this.optionCheck.Size = new System.Drawing.Size(260, 20);
            this.optionCheck.TabIndex = 1;
            this.optionCheck.Text = "Check for something first.";
            // 
            // pageFinish
            // 
            this.pageFinish.Description = "Thank you for using the Sample Wizard.\nPress OK to exit.";
            this.pageFinish.Location = new System.Drawing.Point(0, 0);
            this.pageFinish.Name = "pageFinish";
            this.pageFinish.Size = new System.Drawing.Size(466, 296);
            this.pageFinish.Style = CristiPotlog.Controls.WizardPageStyle.Finish;
            this.pageFinish.TabIndex = 12;
            this.pageFinish.Title = "Sample Wizard has finished";
            // 
            // wizardSample
            // 
            this.wizardSample.Controls.Add(this.pageOptions);
            this.wizardSample.Controls.Add(this.pageCheck);
            this.wizardSample.Controls.Add(this.pageLicense);
            this.wizardSample.Controls.Add(this.pageWelcome);
            this.wizardSample.Controls.Add(this.pageFinish);
            this.wizardSample.Controls.Add(this.pageProgress);
            this.wizardSample.HeaderImage = ((System.Drawing.Image)(resources.GetObject("wizardSample.HeaderImage")));
            this.wizardSample.HelpVisible = true;
            this.wizardSample.Location = new System.Drawing.Point(0, 0);
            this.wizardSample.Name = "wizardSample";
            this.wizardSample.Pages.AddRange(new CristiPotlog.Controls.WizardPage[] {
                                                                                        this.pageWelcome,
                                                                                        this.pageLicense,
                                                                                        this.pageOptions,
                                                                                        this.pageCheck,
                                                                                        this.pageProgress,
                                                                                        this.pageFinish});
            this.wizardSample.Size = new System.Drawing.Size(466, 344);
            this.wizardSample.TabIndex = 0;
            this.wizardSample.WelcomeImage = ((System.Drawing.Image)(resources.GetObject("wizardSample.WelcomeImage")));
            this.wizardSample.Help += new System.EventHandler(this.wizardSample_Help);
            this.wizardSample.BeforeSwitchPages += new CristiPotlog.Controls.Wizard.BeforeSwitchPagesEventHandler(this.wizardSample_BeforeSwitchPages);
            this.wizardSample.Cancel += new System.ComponentModel.CancelEventHandler(this.wizardSample_Cancel);
            this.wizardSample.AfterSwitchPages += new CristiPotlog.Controls.Wizard.AfterSwitchPagesEventHandler(this.wizardSample_AfterSwitchPages);
            this.wizardSample.Finish += new System.EventHandler(this.wizardSample_Finish);
            // 
            // pageWelcome
            // 
            this.pageWelcome.Description = "This wizard will guide you through the steps of performing a sample task.";
            this.pageWelcome.Location = new System.Drawing.Point(0, 0);
            this.pageWelcome.Name = "pageWelcome";
            this.pageWelcome.Size = new System.Drawing.Size(466, 296);
            this.pageWelcome.Style = CristiPotlog.Controls.WizardPageStyle.Welcome;
            this.pageWelcome.TabIndex = 9;
            this.pageWelcome.Title = "Welcome to the Sample  Wizard";
            // 
            // pageProgress
            // 
            this.pageProgress.Controls.Add(this.labelProgress);
            this.pageProgress.Controls.Add(this.progressLongTask);
            this.pageProgress.Description = "This simulates a long running sample task.";
            this.pageProgress.Location = new System.Drawing.Point(0, 0);
            this.pageProgress.Name = "pageProgress";
            this.pageProgress.Size = new System.Drawing.Size(428, 208);
            this.pageProgress.TabIndex = 10;
            this.pageProgress.Title = "Task Running";
            // 
            // labelProgress
            // 
            this.labelProgress.Location = new System.Drawing.Point(20, 84);
            this.labelProgress.Name = "labelProgress";
            this.labelProgress.Size = new System.Drawing.Size(252, 16);
            this.labelProgress.TabIndex = 1;
            this.labelProgress.Text = "Please wait while the wizard does a long task...";
            // 
            // progressLongTask
            // 
            this.progressLongTask.Location = new System.Drawing.Point(16, 104);
            this.progressLongTask.Name = "progressLongTask";
            this.progressLongTask.Size = new System.Drawing.Size(436, 20);
            this.progressLongTask.TabIndex = 0;
            // 
            // pageCheck
            // 
            this.pageCheck.Controls.Add(this.labelPlaceholder);
            this.pageCheck.Description = "Please enter required information.";
            this.pageCheck.Location = new System.Drawing.Point(0, 0);
            this.pageCheck.Name = "pageCheck";
            this.pageCheck.Size = new System.Drawing.Size(466, 296);
            this.pageCheck.TabIndex = 13;
            this.pageCheck.Title = "Ckeck Something";
            // 
            // timerTask
            // 
            this.timerTask.Tick += new System.EventHandler(this.timerTask_Tick);
            // 
            // labelPlaceholder
            // 
            this.labelPlaceholder.ForeColor = System.Drawing.Color.Red;
            this.labelPlaceholder.Location = new System.Drawing.Point(28, 100);
            this.labelPlaceholder.Name = "labelPlaceholder";
            this.labelPlaceholder.Size = new System.Drawing.Size(384, 16);
            this.labelPlaceholder.TabIndex = 0;
            this.labelPlaceholder.Text = "Place some validation controls here.";
            // 
            // SampleWizard
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(466, 344);
            this.Controls.Add(this.wizardSample);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SampleWizard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sample Wizard";
            this.pageLicense.ResumeLayout(false);
            this.pageOptions.ResumeLayout(false);
            this.groupOptions.ResumeLayout(false);
            this.wizardSample.ResumeLayout(false);
            this.pageProgress.ResumeLayout(false);
            this.pageCheck.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

		#region Methods
		/// <summary>
		/// Starts a sample task simulation.
		/// </summary>
		private void StartTask()
		{
			// setup wizard page
			this.wizardSample.BackEnabled = false;
			this.wizardSample.NextEnabled = false;
			this.progressLongTask.Value = this.progressLongTask.Minimum;

			// start timer to simulate a long running task
			this.timerTask.Enabled = true;
		}

		#endregion

		#region Events handlers
		/// <summary>
		/// Handles the CheckedChanged event of checkIAgree.
		/// </summary>
		private void checkIAgree_CheckedChanged(object sender, System.EventArgs e)
		{
			// sync next button's state with check box
			this.wizardSample.NextEnabled = this.checkIAgree.Checked;
		}

		/// <summary>
		/// Handles the AfterSwitchPages event of wizardSample.
		/// </summary>
		private void wizardSample_AfterSwitchPages(object sender, CristiPotlog.Controls.Wizard.AfterSwitchPagesEventArgs e)
		{
			// get wizard page to be displayed
			WizardPage newPage = this.wizardSample.Pages[e.NewIndex];

			// check if license page
			if (newPage == this.pageLicense)
			{
				// sync next button's state with check box
				this.wizardSample.NextEnabled = this.checkIAgree.Checked;
			}
			// check if progress page
			else if (newPage == this.pageProgress)
			{
				// start the sample task
				this.StartTask();
			}
		}

		/// <summary>
		/// Handles the BeforeSwitchPages event of wizardSample.
		/// </summary>
		private void wizardSample_BeforeSwitchPages(object sender, CristiPotlog.Controls.Wizard.BeforeSwitchPagesEventArgs e)
		{
			// get wizard page already displayed
			WizardPage oldPage = this.wizardSample.Pages[e.OldIndex];

			// check if we're going forward from options page
			if (oldPage == this.pageOptions && e.NewIndex > e.OldIndex)
			{
				// check if user selected one option
				if (this.optionCheck.Checked == false &&
					this.optionSkip.Checked == false)
				{
					// display hint & cancel step
					MessageBox.Show("Please chose one of the options presented.",
									this.Text,
									MessageBoxButtons.OK,
									MessageBoxIcon.Information);
					e.Cancel = true;
				}
                // check if user choosed to skip validation
                else if (this.optionSkip.Checked)
                {
                    // skip the validation page
                    e.NewIndex++;
                }
			}
		}

		/// <summary>
		/// Handles the Cancel event of wizardSample.
		/// </summary>
		private void wizardSample_Cancel(object sender, System.ComponentModel.CancelEventArgs e)
		{
			// check if task is running
			bool isTaskRunning = this.timerTask.Enabled;
			// stop the task
			this.timerTask.Enabled = false;

			// ask user to confirm
			if (MessageBox.Show("Are you sure you wand to exit the Sample Wizard?",
								this.Text,
								MessageBoxButtons.YesNo,
								MessageBoxIcon.Question) != DialogResult.Yes)
			{
				// cancel closing
				e.Cancel = true;
				// restart the task
				this.timerTask.Enabled = isTaskRunning;
			}
		}

		/// <summary>
		/// Handles the Finish event of wizardSample.
		/// </summary>
        private void wizardSample_Finish(object sender, System.EventArgs e)
        {
            MessageBox.Show("The Sample Wizard finished succesfuly.",
							this.Text,
							MessageBoxButtons.OK,
							MessageBoxIcon.Information);
        }

		/// <summary>
		/// Handles the Help event of wizardSample.
		/// </summary>
        private void wizardSample_Help(object sender, System.EventArgs e)
        {
            MessageBox.Show("This is a realy cool wizard control!\n:-)",
							this.Text,
							MessageBoxButtons.OK,
							MessageBoxIcon.Information);
        }

		/// <summary>
		/// Handles the Tick event of timerTask.
		/// </summary>
		private void timerTask_Tick(object sender, System.EventArgs e)
		{
			// check if task compleeted
			if (this.progressLongTask.Value == this.progressLongTask.Maximum)
			{
				// stop the timer & switch to next page
				this.timerTask.Enabled = false;
				this.wizardSample.Next();
			}
			else
			{
				// update progress bar
				this.progressLongTask.PerformStep();
			}
		}

		#endregion

	}
}
